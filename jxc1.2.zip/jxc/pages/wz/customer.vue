<template>
	<view>
		<ul class="bdi">
			<li>客户姓名：{{customer.customerName}}</li>
			<li>联系人：{{customer.contacts}}</li>
			<li>地址：{{customer.address}}</li>
			<li>电话号码：{{customer.phoneNumber}}</li>
			<li>备注：{{customer.remarks}}</li>
		</ul>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				customer: {},
				remarks:''
			}
		},
		onLoad(x) {
			console.log(x),
				uni.request({
					url: `https://i80593u224.zicp.fun/queryCustomerInfoById?id=${x.id}`,
					success: (res) => {
						if (res.data.code * 1 == 200) {
							this.customer = res.data.result;
							//console.log(this.customer);
						}
					}
				})
		},
		methods: {

		}
	}
</script>

<style>
.bdi{
}
</style>