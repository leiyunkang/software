<template>
	<view class="wrap">
		<view class="u-demo-wrap">
			<u-section font-size="35" title="起始日期" :sub-title="perf.saleDate_1" :show-line="false" :arrow="true" @click="showCalender1 = true"></u-section>
		</view>
		<view class="u-demo-wrap">
			<u-section font-size="35" title="截至日期" :sub-title="perf.saleDate_2" :show-line="false" :arrow="true" @click="showCalender2 = true"></u-section>
		</view>
		<u-button @click="submit()" style="background-color: #1296db; color: white; left: 20%; width: 60%; margin-top: 5px;">查询</u-button>
		<u-popup v-model="show" mode="bottom" border-radius="14" height="95px">
			<view class="tan">在{{resu.saleDate_1}}到{{resu.saleDate_2}}<br />您的总销售额为<span
					class="money">{{resu.totalSales}}</span>元<br />请继续狠狠的工作嗷！</view>
		</u-popup>
		<u-button @click="showtable()" style="background-color: #1296db; color: white; left: 20%; width: 60%; margin-top: 5px;">showshow近来业绩</u-button>
		<view class="chart">
			<canvas canvas-id="dDHOmDfvkprXDVMyHmAzegeRjPsPBWyf" id="dDHOmDfvkprXDVMyHmAzegeRjPsPBWyf" class="charts"
				@touchend="tap" />
		</view>
		<view>
			<u-calendar v-model="showCalender1" mode="date" @change="choseDate1" min-date="1970-01-01" max-date="2050-01-01"></u-calendar>
		</view>
		<view>
			<u-calendar v-model="showCalender2" mode="date" @change="choseDate2" min-date="1970-01-01" max-date="2050-01-01"></u-calendar>
		</view>
	</view>
</template>

<script>
	import uCharts from '@/pages/u-charts.js';
	var uChartsInstance = {};
	export default {
		data() {
			return {
				perf: {
					userId: "1",
					trueName: "",
					saleDate_1: "2022-01-01",
					saleDate_2: "2023-01-01",
				},
				resu: {

				},
				perm: {},
				show: false,
				cWidth: 750,
				cHeight: 500,
				
				showCalender1: false,
				showCalender2: false,
				
			}
		},
		onLoad() {
			this.perf.userId = 1;
			this.getDateStr();
		},
		methods: {
			submit() {
				uni.request({
					url: 'https://i80593u224.zicp.fun/performance',
					data: this.perf,
					method: "POST",
					success: (res) => {
						if (res.data.code * 1 == 200) {
							try {
								this.resu = res.data.result;
								this.resu.saleDate_1 = this.resu.saleDate_1.substring(0, 10);
								this.resu.saleDate_2 = this.resu.saleDate_2.substring(0, 10);
								console.log(this.resu);
								this.show = true;
							} catch (e) {
								this.$u.toast('查询失败，数据错误')
							}
						} else {
							this.$u.toast('查询失败,请输入正确的日期')
						}
					}
				});
			},
			showtable() {
				uni.request({
					url: 'https://i80593u224.zicp.fun/monthPerformancew',
					data: this.perf,
					method: "POST",
					success: (res) => {
						if (res.data.code * 1 == 200) {
							try {
								this.perm = res.data.result;
								this.cWidth = uni.upx2px(750);
								//这里的 500 对应 css .charts 的 height
								this.cHeight = uni.upx2px(500);
								this.getServerData();
							} catch (e) {
								this.$u.toast('图表加载错误')
							}
						} else {
							this.$u.toast('图表数据加载错误')
						}
					}
				});
			},
			getServerData() {
				setTimeout(() => {
					var j = this.perm[0].totalSales;
					console.log(this.perm.length);
					var value = this.perm.map(item => item.totalSales);
					var category = this.perm.map(item => item.saleDate.substring(2, 7))
					console.log(category);
					let categories = category;
					let data = value;
					let res = {
						categories: categories,
						series: [{
							name: "销售额",
							data: data,
						}]
					};
					this.drawCharts('dDHOmDfvkprXDVMyHmAzegeRjPsPBWyf', res);
				}, 500);
			},
			drawCharts(id, data) {
				const ctx = uni.createCanvasContext(id, this);
				uChartsInstance[id] = new uCharts({
					type: "column",
					context: ctx,
					width: this.cWidth,
					height: this.cHeight,
					categories: data.categories,
					series: data.series,
					animation: true,
					background: "#ffffff",
					color: ["#00007f", "#aa007f", "#00557f", "#aa557f", "#00aa7f", "#ff557f", "#00aaff", "#ff557f",
						"#000000"
					],
					padding: [15, 15, 0, 5],
					enableScroll: false,
					legend: {},
					xAxis: {
						disableGrid: true,
						axisLabelFontSize: 5,
						rotateLabel: true,
						name: '月份'
					},
					yAxis: {
						data: [{
							min: 0
						}],
						name: '销售额（万元）'
					},
					extra: {
						column: {
							type: "group",
							width: 25,
							activeBgColor: "#000000",
							activeBgOpacity: 0.08,
							linearType: "custom",
							seriesGap: 10,
							linearOpacity: 0.5,
							barBorderCircle: true,
							customColor: [
								"#FA7D8D",
								"#EB88E2"
							]
						}
					}
				});
			},
			tap(e) {
				uChartsInstance[e.target.id].touchLegend(e);
				uChartsInstance[e.target.id].showToolTip(e);
			},
			choseDate1(e){
				this.perf.saleDate_1=e.result;
			},
			choseDate2(e){
				this.perf.saleDate_2=e.result;
			},
			getDateStr(){
				var date = new Date();
				var year = date.getFullYear();    
				var month = date.getMonth() + 1;  
				var dates = date.getDate();  
				if(month<10) month="0"+month;
				if(dates<10) dates="0"+dates;
			
				this.perf.saleDate_2 = year + "-" + month + "-" + dates;
				console.log(this.perf.saleDate_2)
			}
			
		}

	}
</script>

<style>
	.u-demo-area {
		cursor: pointer;
	}

	.tan {
		font-size: 20px;
		text-align: center;
		background-color: aquamarine;
	}

	.money {
		font-size: 30px;
		color: red;
	}

	.chart {
		position: relative;
		right: 10px;
		top: 80px;
	}

	.charts {
		width: 750rpx;
		height: 500rpx;
	}
	.u-demo-wrap {
		border-width: 1px;
		border-color: #ddd;
		border-style: double;
		background-color: rgb(250, 250, 250);
		margin-top: 5px;
		margin-left: 2px;
		margin-right: 2px;
		padding: 15px 10px;
		border-radius: 10px;
	}
</style>