<template>
	<view>
		<view v-if="vif" class="">
			<!-- 所有内容的容器 -->
			<view class="">
				<view class="u-demo-wrap">
					<u-section font-size="35" title="单据单号" :sub-title="currentSaleId" :show-line="false" :arrow="false"></u-section>
				</view>
				<view class="u-demo-wrap">
					<u-section font-size="35" title="日期" :sub-title="chosedDate" :show-line="false" :arrow="true" @click="show = true"></u-section>
				</view>
				<view class="u-demo-wrap">
					<u-section font-size="35" title="客户" :sub-title="chosedCustomer.customerName" :show-line="false" :arrow="true" @click="goToChoseCustomer"></u-section>
				</view>
				<view class="u-demo-wrap">
					<u-section font-size="35" title="是否付款" :sub-title="isPay" :show-line="false" :arrow="true" @click="selectShow=true"></u-section>
				</view>
				<view class="u-demo-wrap">
					<u-section font-size="35" title="选择货品" :sub-title="chosedCarNum" :show-line="false" :arrow="true" @click="goToChoseCar"></u-section>
				</view>
				<view class="wrap">
							<view class="item u-border-bottom u-demo-wrap " style="background-color:azure;" v-for="(item, index) in SaleListGoods" :key="index">
								{{item.goodsCode+' '+item.goodsName+' 出库价 '+item.price+' 数量 '+item.goodsNum+' 总价 '+item.total}}<br/>
							</view>
				</view>
				<view class="u-demo-wrap">
					<u-section font-size="35" title="应付金额" :sub-title="needPay+' 元'" :show-line="false" :arrow="false"></u-section>
				</view>
				<view class="u-demo-wrap">
						<u-field
							v-model="realPay"
							label="实付金额"
								>
						</u-field>
						<u-field
							v-model="remark"
							label="备注"
								>
						</u-field>		
				</view>
			</view>
			<view>
				<u-select v-model="selectShow" mode="single-column" :list="isPayList" @confirm="confirm"></u-select>
				<u-calendar v-model="show" mode="date" @change="choseDate" :min-date="nowDate" max-date="2050-01-01"></u-calendar>
			</view>
			<view style="position: fixed; left: 20%; width: 60%; bottom: 80px;">
				<u-button  @click="submit" style="background-color: #1296db; color: white;">提交</u-button>
			</view>
		
			<view>
					<u-toast ref="uToast" />
			</view>
		</view>
		<view v-else style=" position: fixed; top:100px ;left: 125px; font-size: 29px;">
			<u-icon name="info-circle" size="50" color="red"></u-icon>
			请登录
		</view>
		<!-- 与包裹页面所有内容的元素u-page同级，且在它的下方 -->
		<!-- <u-tabbar v-model="current" :list="list" :mid-button="true"></u-tabbar> -->
	</view>

</template>

<script>
	export default {
		onLoad() {
			this.getDateStr();
			uni.getStorageSync('user');
			if(uni.getStorageSync('user')!=null){
			 this.userId=uni.getStorageSync('user').userId;
			}
		},
		onShow() {
				this.initCurrentSaleId();
				if(uni.getStorageSync("chosedCars").length>0){
					this.SaleListGoods = uni.getStorageSync("chosedCars");
					console.log("car"+this.SaleListGoods);
					this.getNeedPay();
					uni.setStorageSync("chosedCars",[]);
				}
				if(uni.getStorageSync("chosedCustomer").customerId!=undefined){
					this.chosedCustomer = uni.getStorageSync("chosedCustomer");
					console.log(this.chosedCustomer);
					uni.setStorageSync("chosedCustomer",{});
				}
				var userid = uni.getStorageSync('user');
				if(userid==""){
					this.vif=false;
				}else{
					this.vif=true;
				}
		},
		data() {
			return {
				vif:false,
				currentSaleId: null,
				current: 0,
				
				SaleListGoods: [],
				chosedCustomer: {},
				chosedDate:null,
				realPay: null,
				needPay: 0,
				remark: null,
				show: false,
				isPay: '已付',
				userId: 1,//暂时设置为常数1，后续合并从缓存中取
				listId: null,
				
				saleList: {},
				
				query:{},
				
				nowDate: null,
				
				selectShow:false,
				chosedCarNum: 0,
				isPayList: [
					{
						value: 1,
						label: "已付"
					},
					{
						value: 2,
						label: "未付"
					}
				]
			}
		},
		methods: {
			genOddNumbers(type) {
				return type + new Date().getTime();
			},
			initCurrentSaleId(){
				this.currentSaleId = this.genOddNumbers('JX');
			},
			goToChoseCar(){
				uni.navigateTo({
					url:"/pages/dxy/choosecar - purchase",
				})
			},
			goToChoseCustomer(){
				uni.navigateTo({
					url:"/pages/dxy/ChooseCustomer",
				})
			},
			getNeedPay(){
				for(var i=0;i<this.SaleListGoods.length;i++){
					this.needPay = this.needPay+this.SaleListGoods[i].total;
					this.chosedCarNum=this.chosedCarNum+Number(this.SaleListGoods[i].goodsNum);
				}
				this.chosedCarNum=this.chosedCarNum+'辆';
			},
			getDateStr(){
				var date = new Date();
				var year = date.getFullYear();    
				var month = date.getMonth() + 1;  
				var dates = date.getDate();  
				if(month<10) month="0"+month;
				if(dates<10) dates="0"+dates;

				this.nowDate = year + "-" + month + "-" + dates;
				console.log(this.nowDate);
			},
			choseDate(e){
				this.chosedDate=e.result;
			},
			submit(){
				//得到当前用户的user id，用来开销售单
				//this.userId = uni.getStorageSync("user").user_id
				if(this.SaleListGoods.length>0 && this.chosedCustomer!={} && this.realPay!=null && this.chosedDate!=null){
					this.saleList.returnNumber=this.currentSaleId;
					this.saleList.returneDate=this.chosedDate;
					this.saleList.amountPaid=this.realPay;
					this.saleList.amountPayable=this.needPay;
					this.saleList.remarks=this.remark;
					if(this.isPay=='已付') this.saleList.state=1;
					else this.saleList.state=2;
					this.saleList.supplierId=this.chosedCustomer.customerId;
					this.saleList.userId=this.userId;
					
					uni.request({
						url: 'https://i80593u224.zicp.fun/savereturnlist',
						method: "POST",
						data: this.saleList,
						success:(res)=>{
							console.log(res.data)
							if(res.data.code==200){
								this.listId=res.data.result;
								
								this.query.listReturnListGooods=this.SaleListGoods;
								this.query.listId=this.listId;
								
								uni.request({
									url:'https://i80593u224.zicp.fun/savereturnlistgoods',
									method:"POST",
									data:this.query,
									success:(res)=>{
										console.log(res.data);
										if(res.data.code==200){
											this.$refs.uToast.show({
													title: '提交成功',
													type: 'success'
											});
											setTimeout(() => {
												this.$router.go(0)
											}, 400)
										}else{
											this.$refs.uToast.show({
														title: '提交失败！请检查填写信息',
														type: 'error'
											});
										}
									}
								})
								
							}else{
								this.$refs.uToast.show({
											title: '提交失败！请检查填写信息',
											type: 'error'
								});
							}
						}
					})
				}else{
					this.$refs.uToast.show({
								title: '提交失败！请检查填写信息',
								type: 'error'
					});
				}
			},
			confirm(e){
				console.log(e);
				this.isPay=e[0].label;
				console.log(this.isPay);
			}
		}
	}
</script>

<style lang="scss" scoped>
	.u-demo-wrap {
		border-width: 1px;
		border-color: #ddd;
		border-style: double;
		background-color: rgb(250, 250, 250);
		margin-top: 5px;
		margin-left: 2px;
		margin-right: 2px;
		padding: 15px 10px;
		border-radius: 10px;
	}
</style>
