<template>
	<view>
		<view class="u-page">
				<view class="">
					<u-field
						v-model="query.namelike"
						icon="/static/images/search.png"
						placeholder="客户名称"
						type="text"
					>
						<u-button style="background-color: #1296db;" size="mini" slot="right" type="success" @click="clickgetCustomersList">搜索</u-button>
					</u-field>
				</view>
				<view class="wrap">
							<view class="item u-border-bottom u-demo-wrap" v-for="(item, index) in Customerslist" :key="index">
								{{'编号 '+item.customerId+' 客户名称 '+item.customerName}}<br/>
								{{'联系人 '+item.contacts+' 联系人电话 '+item.phoneNumber}}<br/>
								{{'客户地址 '+item.address}}<br/>
								{{'备注 '+item.remarks+'&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp'}}
								<u-button @click="choseCutomer(index)" size="mini">选择</u-button>
							</view>
				</view>
		</view>
		<view>
				<u-toast ref="uToast" />
		</view>
	</view>
</template>

<script>
	export default {
		onLoad() {
				
		},
		onShow() {
			this.clickgetCustomersList();
		},
		onUnload() {
			if(this.chosedCustomer!={}){
				uni.setStorageSync("chosedCustomer",this.chosedCustomer);
			}
		},
		data() {
			return {
				query: {
					namelike: "",
				},
				Customerslist: [],
				chosedCustomer: {}
			}
		},
		methods: {
			clickgetCustomersList(){
				this.Customerslist=[];
				uni.request({
					url: 'https://i80593u224.zicp.fun/getcustomerlist',
					method:"POST",
					data:this.query,
					success:(res)=>{
						console.log(res.data);
						for(var i=0;i<res.data.result.length;i++){
							this.Customerslist.push(res.data.result[i]);
						}
						console.log(this.Customerslist);
					}
				})
			},
			choseCutomer(index){
				this.chosedCustomer = this.Customerslist[index];
				this.$refs.uToast.show({
							title: '选择成功',
							type: 'success'
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.wrap {
		padding: 24rpx;
	}
	
	.item {
		padding: 24rpx 0;
		color: $u-content-color;
		font-size: 28rpx;
		height: 100px;
	}
	.u-demo-wrap {
		border-width: 1px;
		border-color: #ddd;
		border-style: double;
		background-color: rgb(250, 250, 250);
		margin-top: 5px;
		padding: 15px 10px;
		border-radius: 10px;
	}
</style>