<template>
	<view>
		<view class="u-page">
				<view class="">
					<u-field
						v-model="NameOrCode"
						icon="/static/images/search.png"
						placeholder="车型、编号"
						type="text"
					>
						<u-button style="background-color: #1296db;" size="mini" slot="right" type="success" @click="clickgetCarsList">搜索</u-button>
					</u-field>
				</view>
				<view class="">
						<u-dropdown active-color="#1296db" border-bottom="true">
							<u-dropdown-item @change="selectDD" v-model="brand" :title="brand"  :options="brandOptions"></u-dropdown-item>
							<u-dropdown-item @change="selectDD" v-model="model" :title="modelname"  :options="modelOptions"></u-dropdown-item>
						</u-dropdown>
				</view>
				<view class="wrap">
							<view class="item u-demo-wrap" v-for="(item, index) in carlist" :key="index" @click="showPopUp(index)">
								{{item.goodsProducer+'  '+item.goodsName+' 进价:'+item.purchasingPrice+'万元'}}<br/>
								{{item.goodsTypeName}}<br/>
								{{'配置:'+item.goodsModel+' 库存:'+item.inventoryQuantity}}
								
							</view>
							<u-loadmore :status="status" />
				</view>
				<u-popup v-model="popUpShow" mode="top" length="40%" border-radius="14">
					<br/>
					<view class="u-demo-wrap" style="padding: 7px; font-size: 13px;margin-left: 5px; margin-right: 5px; margin-bottom: 5px;">
						{{'编号: '+currentCar.goodsCode+' '+currentCar.goodsProducer+' '+currentCar.goodsName}}<br/>
						{{'型号: '+currentCar.goodsModel}}<br/>
						{{'进货单价: '+currentCar.purchasingPrice+' 万元 库存: '+currentCar.inventoryQuantity+' 单位: '+currentCar.goodsUnit}}<br/>
					</view>
					<view class="u-demo-wrap" style="margin-left: 5px; margin-right: 5px; margin-bottom: 5px;">
							<u-field
								v-model="realPrice"
								label="入库单价"
							>
							</u-field>
							<u-field
								v-model="amountCar"
								label="数量"
							>
							</u-field>
					</view>
					<view style="position: fixed; left: 20%; width: 60%; bottom: 15px;">
						<u-button @click="closePopUp" style="margin-bottom: 5px; background-color: #1296db; color: white;">取消</u-button>
						<u-button @click="addCarToList" style="background-color: #1296db; color: white;">确定</u-button>
					</view>
				</u-popup>
		</view>
		<view>
				<u-toast ref="uToast" />
		</view>
	</view>
</template>

<script>
	export default {
		onLoad() {
				this.getBrand();
				this.getModel();
		},
		onShow() {
			this.initBrandModel();
			this.clickgetCarsList();
		},
		onUnload() {
			if(this.SaleListGoods.length>0){
				uni.setStorageSync("chosedCars",this.SaleListGoods);
			}
		},
		data() {
			return {
				brand: "品牌",
				model: 0,
				modelname: null,
				query: {
					page: 1,
					rows: 20,
					brand: null,
					codeOrName: null,
					goodsTypeId: null,
				},
				brandOptions: [{label:'所有',value:'所有'}],
				modelOptions: [{label:'所有',value:0}],
				NameOrCode:null,
				current: 0,
				status: 'loadmore',
				carlist: [],
				carlistnum: 1,
				allcarnum: null,
				page: 0,
				
				popUpShow: false,
				currentCarIndex:null,
				currentCar: {},
				realPrice:null,
				amountCar:null,
				SaleListGoods: []
			}
		},
		onReachBottom() {
					if(this.query.page*this.query.rows >= this.carlistnum && this.carlist<this.query.rows) return ;
					console.log("启动");
					this.status = 'loading';
					this.query.page = ++ this.query.page;
					setTimeout(() => {
						this.getCarsList();
						if(this.query.page*this.query.rows >= this.carlistnum) this.status = 'nomore';
						else this.status = 'loading';
					}, 2000)
				},
		methods: {
			checkModelNameById(modeloption){
				return modeloption.value==this.model;
			},
			getlog(){
				console.log("query.page:"+this.query.page);
				console.log("query.brand:"+this.query.brand);
				console.log("query.typeid:"+this.query.goodsTypeId);
				console.log("brand:"+this.brand)
				console.log("model:"+this.model)
				console.log("code or name:"+this.query.codeOrName);
				console.log("goodsTypeId:"+this.query.goodsTypeId)
			},
			selectDD(value){
				//console.log(value);
				//console.log(this.brand);
				//console.log(this.model);
				var tempModelName = this.modelOptions.find(this.checkModelNameById).label;
				if(tempModelName!=undefined) this.modelname=tempModelName;
				console.log("selectDD");
				this.getlog();
				this.clickgetCarsList();
			},
			getBrand(){
				uni.request({
					url:'https://i80593u224.zicp.fun/supplier/getComboboxList',
					method:"GET",
					success:(res)=>{
						console.log(res.data);
						for(var i=0;i<res.data.length;i++){
							let brand = {label:null,value:null};
							brand.label=res.data[i].supplierName;
							brand.value=res.data[i].supplierName;
							this.brandOptions.push(brand);
						}
					}
				})
			},
			getModel(){
				uni.request({
					url:'https://i80593u224.zicp.fun/loadCarsType',
					method:"GET",
					success:(res)=>{
						console.log(res.data.result)
						for(var i=0;i<res.data.result.length;i++){
							let model = {label:null,value:null};
							model.label=res.data.result[i].goods_type_name;
							model.value=res.data.result[i].goods_type_id;//
							console.log(model);
							this.modelOptions.push(model);
						}
					}
				})
			},
			setQuery(){
				this.query.codeOrName=this.NameOrCode;
				if(this.model==0){
						this.query.goodsTypeId=null;
				}else{
					if(this.model!="车型"){
						this.query.goodsTypeId=this.model;
					}
				}
				if(this.brand=='所有'){
						this.query.brand=null;
				}else{
					if(this.brand!="品牌"){
						this.query.brand=this.brand;
					}	
				}
			},
			initBrandModel(){
				this.brand="品牌";
				this.model=0;
				this.modelname="车型";
			},
			getCarsListNum(){
					this.setQuery();
					console.log("getCarsListNum");
					this.getlog();
					uni.request({
						url: 'https://i80593u224.zicp.fun/getCarsInventoryNum',
						method:"POST",
						data:this.query,
						success:(res)=>{
							console.log(res.data);
							if(res.data.code*1==200){
								this.carlistnum=res.data.result;
								if(this.allcarnum==null) this,allcarnum=res.data.result;
							}
						}
					})
			},
			getCarsList(){
				this.setQuery();
				this.getCarsListNum();
				console.log("getCarsList");
				this.getlog();
				uni.request({
					url: 'https://i80593u224.zicp.fun/getCarsInventory',
					method:"POST",
					data:this.query,
					success:(res)=>{
						console.log(res.data);
						if(res.data.code*1==200){
						for(var i=0;i<res.data.result.length;i++){
							this.carlist.push(res.data.result[i]);
						}
						console.log(this.carlist);
						}
					}
				})
			},
			clickgetCarsList(){
				this.query.page=1;
				this.carlist=[];
				console.log("clickgetCarsList");
				this.getCarsList();
			},
			showPopUp(index){
				console.log("******/*****:"+index);
				this.currentCarIndex = index;
				console.log("this.currentCarIndex:"+this.currentCarIndex)
				this.currentCar = this.carlist[this.currentCarIndex];
				console.log(this.currentCar.goodsCode);
				this.popUpShow = true;
				this.realPrice = this.currentCar.purchasingPrice;
			},
			closePopUp(){
				this.popUpShow = false;
			},
			addCarToList(){
				if(this.amountCar!=null && this.amountCar>0 &&this.amountCar<=this.currentCar.inventoryQuantity){
					let saledCar={goodsId:null,goodsCode:null,goodsName:null,goodsModel:null,goodsNum:null,
					goodsUnit:null,price:null,total:null,saleListId:null,goodsTypeId:null};
					saledCar.goodsId = this.currentCar.goodsId;
					saledCar.goodsCode = this.currentCar.goodsCode;
					saledCar.goodsName = this.currentCar.goodsName;
					saledCar.goodsModel = this.currentCar.goodsModel;
					saledCar.goodsNum = this.amountCar;
					saledCar.goodsUnit = this.currentCar.goodsUnit;
					saledCar.price = this.realPrice;
					saledCar.total = this.realPrice*this.amountCar;
					saledCar.goodsTypeId = this.currentCar.goodsTypeId;
					this.SaleListGoods.push(saledCar);
					this.$refs.uToast.show({
								title: '添加成功',
								type: 'success'
					});
					this.amountCar=null;
					this.popUpShow=false;
					console.log(this.SaleListGoods.length);
				}else{
					this.$refs.uToast.show({
								title: '数量为空或超过库存量',
								type: 'error'
					})
				}
			}
			
		}
	}
</script>

<style lang="scss" scoped>
	.wrap {
		padding: 24rpx;
	}
	
	.item {
		padding: 24rpx 0;
		color: $u-content-color;
		font-size: 28rpx;
		height: 100px;
	}
	.u-demo-wrap {
		border-width: 1px;
		border-color: #ddd;
		border-style: double;
		background-color: rgb(250, 250, 250);
		margin-top: 5px;
		padding: 15px 10px;
		border-radius: 10px;
	}
</style>
