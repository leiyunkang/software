package com.cqu.entity;

import lombok.Data;

@Data
public class Result {
    private Integer code;
    private Object result;
}
