package com.cqu.entity;

import lombok.Data;

@Data
public class QueryCutom {
    private String namelike;
}
