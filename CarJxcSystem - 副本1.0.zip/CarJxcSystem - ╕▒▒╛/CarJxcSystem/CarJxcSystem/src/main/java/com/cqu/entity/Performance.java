package com.cqu.entity;

import lombok.Data;

import java.util.Date;

@Data
public class Performance {
    private Integer userId;
    private String trueName;
    private String totalSales;
    private Date saleDate_1;
    private Date saleDate_2;

    public void setSaleDate_1(Date saleDate_1) {
        this.saleDate_1 = saleDate_1;
    }
    public void setSaleDate_2(Date saleDate_2) {
        this.saleDate_2 = saleDate_2;
    }
}
