package com.cqu.controller;

import com.cqu.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")//允许跨域
public class controller_1 {
    @Autowired
    private JdbcTemplate jdbc;
    Result res = new Result();

    @PostMapping("/dologin")//http://192.168.1.133:8080/dologin
    public Result dologin(@RequestBody User yonghu) {
        System.out.println(yonghu.getUserName() + yonghu.getPassword());
        System.out.println("***********************************");
        try {//ctrl+alt+T
            User yh = jdbc.queryForObject("select * from t_user where user_name = ? and password = ?",
                    new BeanPropertyRowMapper<>(User.class), yonghu.getUserName(), yonghu.getPassword());
            res.setCode(200);
            res.setResult(yh);
            return res;//返回用户对象
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("密码或账户名错误" + e.getMessage());
            return res;
        }
    }

    @GetMapping("/queryInfoId")//http://192.168.1.133:8080/queryInfoId
    public Result queryInfoId(Integer id) {
        Result res = new Result();
        try {
            User yh = jdbc.queryForObject("select * from t_user where user_id=?", new BeanPropertyRowMapper<>(User.class), id);
            res.setCode(200);
            res.setResult(yh);//用户数据放入结果中
            return res;
        } catch (DataAccessException e) {
            //e.printStackTrace();
            res.setCode(201);
            res.setResult("出现异常" + e.getMessage());//message 异常的信息
            return res;
        }
    }

    @PostMapping("/editmyinfo")//http://192.168.1.133:8080/editmyinfo
    public Result editmyinfo(@RequestBody User yonghu) {
        Result r = new Result();
        try {
            jdbc.update("UPDATE  t_user  SET  true_name = ?  , password =?  WHERE user_id = ?",
                    yonghu.getTrueName(), yonghu.getPassword(), yonghu.getUserId());
            r.setCode(200);
            r.setResult("更新成功");
        } catch (DataAccessException e) {
            r.setCode(201);
            r.setResult("更新失败");
        }
        return r;
    }

    @GetMapping("/queryOrdersById")//http://192.168.1.133:8080/queryOrdersById?id=5
    public Result queryOrdersById(Integer id) {
        Result res = new Result();
        try {
            List<queryOrderById> order = jdbc.query("SELECT t_sale_list.sale_list_id, t_sale_list.sale_number, t_sale_list.amount_paid, " +
                    "       t_sale_list.amount_payable, t_sale_list.sale_date, t_sale_list.user_id, " +
                    "       t_sale_list.customer_id, t_customer.customer_name " +
                    "FROM t_sale_list " +
                    "LEFT JOIN t_customer ON t_sale_list.customer_id = t_customer.customer_id " +
                    "WHERE t_sale_list.user_id = ?;", new BeanPropertyRowMapper<>(queryOrderById.class), id);
            res.setCode(200);
            res.setResult(order);//订单数据放入结果中
            return res;
        } catch (DataAccessException e) {
            //e.printStackTrace();
            res.setCode(201);
            res.setResult("出现异常" + e.getMessage());//message 异常的信息
            return res;
        }
    }

    @GetMapping("/queryCustomerInfoById")//http://192.168.1.133:8080/queryCustomerInfoById
    public Result queryCustomerInfoById(Integer id) {
        Result res = new Result();
        try {
            Customer yh = jdbc.queryForObject("SELECT *FROM t_customer WHERE customer_id = ?;", new BeanPropertyRowMapper<>(Customer.class), id);
            res.setCode(200);
            res.setResult(yh);//用户数据放入结果中
            return res;
        } catch (DataAccessException e) {
            //e.printStackTrace();
            res.setCode(201);
            res.setResult("出现异常" + e.getMessage());//message 异常的信息
            return res;
        }
    }

    @PostMapping("/performance")//http://192.168.1.133:8080/performance
    public Result performance(@RequestBody Performance per) {
        try {//ctrl+alt+T
            Performance perf = jdbc.queryForObject("SELECT u.user_id, u.true_name, ROUND(SUM(sl.amount_paid)) AS total_sales " +
                            "FROM t_user u " +
                            "JOIN t_sale_list sl ON u.user_id = sl.user_id " +
                            "WHERE u.user_id=? AND sl.sale_date >= ? AND sl.sale_date <= ? " +
                            "GROUP BY u.user_id, u.true_name;",
                    new BeanPropertyRowMapper<>(Performance.class), per.getUserId(), per.getSaleDate_1(), per.getSaleDate_2());
            perf.setSaleDate_1(per.getSaleDate_1());
            perf.setSaleDate_2(per.getSaleDate_2());
            res.setCode(200);
            res.setResult(perf);
            System.out.println("************************************");
            System.out.println(res);
            return res;//返回用户对象
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("密码或账户名错误" + e.getMessage());
            return res;
        }
    }

    @PostMapping("/monthPerformancew")//http://192.168.1.133:8080/monthPerformancew
    public Result monthPerformancew(@RequestBody Performance id) {
        List<PerformanceMonth> perf = new ArrayList<>();
        try {//ctrl+alt+T
            List<PerformanceMonth> per = jdbc.query(" SELECT " +
                            "            DATE_FORMAT( t1.sale_date, '%Y-%m' ) AS saleDate, " +
                            "            SUM(t1.amount_paid) AS totalSales " +
                            "        FROM " +
                            "            t_sale_list t1 " +
                            "        WHERE " +
                            "            t1.sale_date BETWEEN '2022-07-01' AND '2023-07-31' " +
                            "          AND t1.user_id = ? " +
                            "        GROUP BY " +
                            "            DATE_FORMAT( t1.sale_date, '%Y-%m' )",
                    new BeanPropertyRowMapper<>(PerformanceMonth.class), id.getUserId());
            List<String> dateList = Arrays.asList("2022-07", "2022-08", "2022-09", "2022-10", "2022-11", "2022-12", "2023-01", "2023-02",
                    "2023-03", "2023-04", "2023-05", "2023-06", "2023-07");
            int i=0;
            for (String date : dateList) {

                PerformanceMonth obj = new PerformanceMonth();

                boolean flag = false;

                for (PerformanceMonth o : per) {

                    if (o.getSaleDate().equals(date)) {
                        obj.setSaleDate(o.getSaleDate()); //日期
                        obj.setTotalSales(o.getTotalSales()); //销售总额
                        flag = true;
                    }
                    if (!flag) {// 如果没有销售数据，那么也需要设置该日的销售数据默认为0
                        obj.setSaleDate(date); //日期
                        obj.setTotalSales(0); //销售总额
                    }
                }
                perf.add(obj);
                i++;
            }
            res.setCode(200);
            res.setResult(perf);
            System.out.println("************************************");
            System.out.println(perf);
            return res;//返回用户对象
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("ID传入错误" + e.getMessage());
            return res;
        }
    }

    @GetMapping("/sayHello")//http://192.168.1.133:8080/sayHello
    public String testGet1() {//http://192.168.1.133:8080/sayHello
        return "你好,SpringBoot";
    }
}
