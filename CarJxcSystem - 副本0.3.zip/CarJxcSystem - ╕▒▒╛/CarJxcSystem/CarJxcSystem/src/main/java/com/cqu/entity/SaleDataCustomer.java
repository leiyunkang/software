package com.cqu.entity;

import lombok.Data;

@Data
public class SaleDataCustomer {

    private String Customer_name;
    private double saleTotal_Customer;

}