package com.cqu.entity;


import lombok.Data;

@Data
public class QueryCarInvent {
    private Integer page;
    private Integer rows;
    private String brand;
    private String codeOrName;
    private Integer goodsTypeId;
}
