package com.cqu.dao;

import com.cqu.entity.Unit;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface UnitDao {

    Integer saveUnit(Unit unit);

    Integer delete(Integer unitId);

    List<Unit> listAll();

    Unit getUnitByUnitId(Integer unitId);
}
