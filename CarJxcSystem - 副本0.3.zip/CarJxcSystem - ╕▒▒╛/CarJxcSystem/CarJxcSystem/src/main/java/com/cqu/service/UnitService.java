package com.cqu.service;

import com.cqu.domain.ServiceVO;
import com.cqu.entity.Unit;

import java.util.Map;

public interface UnitService {

    ServiceVO save(Unit unit);

    ServiceVO delete(Integer unitId);

    Map<String,Object> list();
}
