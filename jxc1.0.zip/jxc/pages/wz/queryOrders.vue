<template>
	<view class="wrap">
		<view>
			<u-search :show-action="true" action-text="搜索" :animation="true" placeholder="输入订单编号查询" v-model="perf.trueName"
				shape="round" margin="15px" @custom="search()" @blur="search()">
			</u-search>
		</view>
		
		<view class="u-demo-wrap">
			<u-section font-size="35" title="起始日期" :sub-title="perf.saleDate_1" :show-line="false" :arrow="true" @click="showCalender1 = true"></u-section>
		</view>
		<view class="u-demo-wrap">
			<u-section font-size="35" title="截至日期" :sub-title="perf.saleDate_2" :show-line="false" :arrow="true" @click="showCalender2 = true"></u-section>
		</view>
		<view>
			<u-calendar v-model="showCalender1" mode="date" @change="choseDate1" min-date="1970-01-01" max-date="2050-01-01"></u-calendar>
		</view>
		<view>
			<u-calendar v-model="showCalender2" mode="date" @change="choseDate2" min-date="1970-01-01" max-date="2050-01-01"></u-calendar>
		</view>
		<u-popup v-model="show" mode="left" border-radius="14" width="150px">
			<div id="pop_top">
				<view class="tan" v-if="orders.length>0" id="popup">
					交易日期：{{orders[index].saleDate}}<br />
					订单编号：{{orders[index].saleNumber}}<br />
					实付金额：{{orders[index].amountPaid}}<br />
					应付金额：{{orders[index].amountPayable}}<br />
					客户姓名：{{orders[index].customerName}}<br />
					销售员ID：{{orders[index].userId}}
				</view>
				<view><br/>
					<img src="../../static/images/yiBai.png"><br/><br/>
					<img src="../../static/images/Bei_2.png">
				</view>
			</div>
		</u-popup>
		<u-dropdown>
			<u-dropdown-item v-model="value1" title="排序" :options="options1"></u-dropdown-item>
			<u-dropdown-item v-model="value2" title="显示" :options="options2"></u-dropdown-item>
		</u-dropdown>
		<u-collapse :accordion="false" v-if="value2*1==1">
			<u-collapse-item :title="'订单编号：'+(order.saleNumber)" v-for="(order, index) in orders" :key="index">
				交易日期：{{order.saleDate}}<br />
				订单编号：{{order.saleNumber}}<br />
				实付金额：{{order.amountPaid}}
				应付金额：{{order.amountPayable}}<br />
				客户姓名：{{order.customerName}}
				销售员ID：{{order.userId}}
			</u-collapse-item>
		</u-collapse>
		<u-collapse :accordion="false" v-else>
			<u-collapse-item :title="(order.saleDate)+' '+(order.customerName)" v-for="(order, index) in orders"
				:key="index">
				交易日期：{{order.saleDate}}<br />
				订单编号：{{order.saleNumber}}<br />
				实付金额：{{order.amountPaid}}
				应付金额：{{order.amountPayable}}<br />
				订单编号：{{order.saleNumber}}
				销售员ID：{{order.userId}}
			</u-collapse-item>
		</u-collapse>
		<view class="wrap">
			<u-back-top :scroll-top="scrollTop"></u-back-top>
			<view style="position: fixed; bottom: 10px; left: 28%;">
				你所热爱的，就是你的生活
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				orders: [],
				keyword: '',
				perf: {
					userId: "",
					trueName: "",
					saleDate_1: "2022-01-01",
					saleDate_2: "2023-01-01",
				},
				perm: {},
				show: false,
				cWidth: 750,
				cHeight: 500,
				
				showCalender1: false,
				showCalender2: false,
				index: 0,
				show: false,
				show_1: 0,
				value1: 1,
				value2: 2,
				options1: [{
					label: '日期顺序',
					value: 1,
				}, ],
				options2: [{
						label: '显示订单ID',
						value: 1,
					},
					{
						label: '显示客户姓名',
						value: 2,
					},
				],
				scrollTop: 0,
			}
		},
		onPageScroll(e) {
			this.scrollTop = e.scrollTop;
		},
		onLoad() {
							this.getDateStr();
				
				uni.request({
					url: 'http://192.168.212.42:8080/getSalelist',
					data: this.perf,
					method: "POST",
					success: (res) => {
						if (res.data.code * 1 == 200) {
							try {
								this.orders = res.data.result;
								
							} catch (e) {
								this.$u.toast('查询失败，数据错误')
							}
						} else {
							this.$u.toast('查询失败,请输入正确的日期')
						}
					}
				});

		},
		methods: {
			
			search() {
				uni.request({
					url: 'http://192.168.212.42:8080/getSalelist',
					data: this.perf,
					method: "POST",
					success: (res) => {
						if (res.data.code * 1 == 200) {
							try {
								this.orders = res.data.result;
								
							} catch (e) {
								this.$u.toast('查询失败，数据错误')
							}
						} else {
							this.$u.toast('查询失败,请输入正确的日期')
						}
					}
				});
				
			},
		
		tap(e) {
				uChartsInstance[e.target.id].touchLegend(e);
				uChartsInstance[e.target.id].showToolTip(e);
			},
		choseDate1(e){
				this.perf.saleDate_1=e.result;
			},
		choseDate2(e){
				this.perf.saleDate_2=e.result;
			},
		getDateStr(){
				var date = new Date();
				var year = date.getFullYear();    
				var month = date.getMonth() + 1;  
				var dates = date.getDate();  
				if(month<10) month="0"+month;
				if(dates<10) dates="0"+dates;
			
				this.perf.saleDate_2 = year + "-" + month + "-" + dates;
				console.log(this.perf.saleDate_2)
			}
			
		}
}
</script>

<style>
	.wrap {
		height: 200vh;
	}

	#pop_top {
		
	}

	#popup {
		background-image: url(../../static/images/beiJing.png);
		padding-top: 200px;
		padding-left: 0px;
	}
	#word{text-align:center;}
	
	.u-demo-wrap {
		border-width: 1px;
		border-color: #ddd;
		border-style: double;
		background-color: rgb(250, 250, 250);
		margin-top: 5px;
		margin-left: 2px;
		margin-right: 2px;
		padding: 15px 10px;
		border-radius: 10px;
		}
</style>