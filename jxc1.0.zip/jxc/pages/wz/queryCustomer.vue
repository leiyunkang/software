<template>
	<u-table>
		<u-search :show-action="true" action-text="搜索" :animation="true" placeholder="输入客户ID查询" v-model="keyword"
			shape="round" margin="15px" @custom="search()" @blur="search()">
		</u-search>
		<u-line color="red" />
		<u-line color="red"></u-line>
		<u-tr>
			<u-th class="top_1">客户姓名</u-th>
			<u-th class="top_1">成交金额</u-th>
			<view class="u-m-l-10 u-p-10">
				<u-icon name="tags" color="#969799" size="28"></u-icon>
			</view>
		</u-tr>
		<u-tr v-for="(orders,index) in orders" :key="index">
			<u-td>{{orders.customerName}}</u-td>
			<u-td>{{orders.amountPayable}}</u-td>
			<view class="u-m-l-10 u-p-10" @click="queryDetails(orders.customerId)">
				<u-icon name="arrow-right" color="#969799" size="28"></u-icon>
			</view>
		</u-tr>
		<view class="wrap">
			<u-back-top :scroll-top="scrollTop"></u-back-top>
			<view style="position: fixed; bottom: 10px; left: 35%;">
				你干嘛，哎呦~~
			</view>
		</view>
	</u-table>
</template>

<script>
	export default {
		data() {
			return {
				keyword: '',
				orders: [],
				show: false,
				index: 0,
				scrollTop: 0,
			}
		},
		onPageScroll(e) {
			this.scrollTop = e.scrollTop;
		},
		onLoad(x) {
			console.log(x),
				uni.request({
					url: `http://192.168.212.42:8080/queryOrdersById?id=${x.id}`,
					success: (res) => {
						if (res.data.code * 1 == 200) {
							this.orders = res.data.result;
							//console.log(this.orders)
						}
					}
				})
		},
		methods: {
			queryDetails(x) {
				uni.navigateTo({
					url: `/pages/wz/customer?id=${x}`
				});
			},
			search() {
				for (this.index = 0; this.index < this.orders.length; this.index++) {
					if (this.keyword == this.orders[this.index].customerId) {
						uni.navigateTo({
							url: `/pages/wz/customer?id=${this.keyword}`
						});
					} else this.$u.toast("找不到这个用户ID")
				}
			}
		}
	}
</script>

<style>
	.wrap {
		height: 200vh;
	}
	#word{
		text-align:center;
	}
</style>