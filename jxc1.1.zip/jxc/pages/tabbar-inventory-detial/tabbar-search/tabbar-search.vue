<template>
	<view>
		<view v-if="vif" class="u-page">
			<!-- 	<view class="">
					<u-field
						v-model="NameOrCode"
						icon="/static/images/search.png"
						placeholder="车型、编号"
						type="text"
					>
						<u-button style="background-color: #1296db;" size="mini" slot="right" type="success" @click="clickgetCarsList">搜索</u-button>
					</u-field>
				</view> -->
<!-- 				<view class="">
						<u-dropdown active-color="#1296db" border-bottom="true">
							<u-dropdown-item @change="selectDD" v-model="brand" :title="brand"  :options="brandOptions"></u-dropdown-item>
							<u-dropdown-item @change="selectDD" v-model="model" :title="modelname"  :options="modelOptions"></u-dropdown-item>
						</u-dropdown>
				</view> -->
				<view class="wrap">
							<view class="u-demo-wrap" v-for="(item, index) in carlist" :key="index">
								{{item.goodsProducer+'  '+item.goodsName+' 售价:'+item.sellingPrice+'万元'}}<br/>
								{{item.goodsTypeName}}<br/>
								{{'配置:'+item.goodsModel+' 库存:'+item.inventoryQuantity}}
								
							</view>
							<u-loadmore :status="status" />
				</view>
		</view>
		<view v-else style=" position: fixed; top:100px ;left: 125px; font-size: 29px;">
			<u-icon name="info-circle" size="50" color="red"></u-icon>
			请登录
		</view>
		<!-- 与包裹页面所有内容的元素u-page同级，且在它的下方 -->
		<!-- <u-tabbar v-model="current" :list="list" :mid-button="true"></u-tabbar> -->
	</view>
</template>

<script>
	export default {
		onLoad() {
				/* this.getBrand();
				this.getModel(); */
		},
		onShow() {
			var userid = uni.getStorageSync('user');
			if(userid==""){
				this.vif=false;
			}else{
				this.vif=true;
			}
/* 			this.initBrandModel(); */
			this.getCarsList();
		},
		data() {
			return {
				vif:false,
				brand: "品牌",
				model: 0,
				modelname: null,
				query: {
					page: 1,
					rows: 20,
					brand: null,
					codeOrName: null,
					goodsTypeId: null,
				},
				brandOptions: [{label:'所有',value:'所有'}],
				modelOptions: [{label:'所有',value:0}],
				NameOrCode:null,
				/* list: [{
						iconPath: "/static/images/goods.png",
						selectedIconPath: "/static/images/goods1.png",
						text: '首页',
						count: 0,
						isDot: false,
						customIcon: false,
						pagePath: "/pages/index/index"
					},
					{
						iconPath: "/static/images/goods.png",
						selectedIconPath: "/static/images/goods1.png",
						text: '库存',
						count: 0,
						isDot: false,
						customIcon: false,
						pagePath: "/pages/index/index"
					},
					{
						iconPath: "/static/images/sale.png",
						selectedIconPath: "/static/images/sale1.png",
						text: '销售',
						isDot: false,
						midButton: true,
						customIcon: false,
						pagePath: "/pages/dxy/sale"
					},
					{
							iconPath: "/static/images/goods.png",
							selectedIconPath: "/static/images/goods1.png",
							text: '进货',
							count: 0,
							isDot: false,
							customIcon: false,
							pagePath: "/pages/index/index"
						},
						{
							iconPath: "/static/images/sale.png",
							selectedIconPath: "/static/images/sale1.png",
							text: '退换',
							isDot: false,
							midButton: true,
							customIcon: false,
							pagePath: "/pages/dxy/sale"
						},
						{
							iconPath: "/static/images/my.png",
							selectedIconPath: "/static/images/my1.png",
							text: '管理',
							count: 0,
							isDot: false,
							customIcon: false,
							pagePath: "/pages/dxy/myself"
						},
						{
							iconPath: "/static/images/my.png",
							selectedIconPath: "/static/images/my1.png",
							text: '我的',
							count: 0,
							isDot: false,
							customIcon: false,
							pagePath: "/pages/dxy/myself"
						},
				],
				 */current: 0,
				status: 'loadmore',
				carlist: [],
				carlistnum: 1,
				allcarnum: null,
				page: 0
			}
		},
		/* onReachBottom() {
					if(this.query.page*this.query.rows >= this.carlistnum && this.carlist.length<this.query.rows) return ;
					console.log("启动");
					this.status = 'loading';
					this.query.page = ++ this.query.page;
					setTimeout(() => {
						this.getCarsList();
						if(this.query.page*this.query.rows >= this.carlistnum) this.status = 'nomore';
						else this.status = 'loading';
					}, 2000)
				}, */
		methods: {
			/* checkModelNameById(modeloption){
				return modeloption.value==this.model;
			},
			getlog(){
				console.log("query.page:"+this.query.page);
				console.log("query.brand:"+this.query.brand);
				console.log("query.typeid:"+this.query.goodsTypeId);
				console.log("brand:"+this.brand)
				console.log("model:"+this.model)
				console.log("code or name:"+this.query.codeOrName);
				console.log("goodsTypeId:"+this.query.goodsTypeId)
			},
			selectDD(value){
				//console.log(value);
				//console.log(this.brand);
				//console.log(this.model);
				var tempModelName = this.modelOptions.find(this.checkModelNameById).label;
				if(tempModelName!=undefined) this.modelname=tempModelName;
				console.log("selectDD");
				this.getlog();
				this.clickgetCarsList();
			}, */
			/* getBrand(){
				uni.request({
					url:'http://192.168.212.42:8080/supplier/getComboboxList',
					method:"GET",
					success:(res)=>{
						console.log(res.data);
						for(var i=0;i<res.data.length;i++){
							let brand = {label:null,value:null};
							brand.label=res.data[i].supplierName;
							brand.value=res.data[i].supplierName;
							this.brandOptions.push(brand);
						}
					}
				})
			}, */
			/* getModel(){
				uni.request({
					url:'http://192.168.212.42:8080/loadCarsType',
					method:"GET",
					success:(res)=>{
						console.log(res.data.result)
						for(var i=0;i<res.data.result.length;i++){
							let model = {label:null,value:null};
							model.label=res.data.result[i].goods_type_name;
							model.value=res.data.result[i].goods_type_id;//
							console.log(model);
							this.modelOptions.push(model);
						}
					}
				})
			}, */
			/* setQuery(){
				this.query.codeOrName=this.NameOrCode;
				if(this.model==0){
						this.query.goodsTypeId=null;
				}else{
					if(this.model!="车型"){
						this.query.goodsTypeId=this.model;
					}
				}
				if(this.brand=='所有'){
						this.query.brand=null;
				}else{
					if(this.brand!="品牌"){
						this.query.brand=this.brand;
					}	
				}
			},
			initBrandModel(){
				this.brand="品牌";
				this.model=0;
				this.modelname="车型";
			}, */
			/* getCarsListNum(){
			
					console.log("getCarsListNum");
					
					uni.request({
						url: 'http://192.168.212.42:8080/getCarsInventoryNum',
						method:"POST",
						success:(res)=>{
							console.log(res.data);
							this.carlistnum=res.data.result;
							if(this.allcarnum==null) this,allcarnum=res.data.result;
						}
					})
			}, */ 
			getCarsList(){
				/* this.setQuery(); */
/* 				this.getCarsListNum(); */
				console.log("getCarsList");
	/* 			this.getlog(); */
				uni.request({
					url: 'http://192.168.212.42:8080/getlistAlarm',
					method:"POST",
					data:this.query,
					success:(res)=>{
						console.log("1111111111111111111111");
						console.log(res.data);
						for(var i=0;i<res.data.result.length;i++){
							this.carlist.push(res.data.result[i]);
						}
						console.log(this.carlist);
					}
				})
			}
		},
		}
</script>

<style lang="scss" scoped>
	.wrap {
		padding: 24rpx;
	}
	
	.item {
		padding: 24rpx 0;
		color: $u-content-color;
		font-size: 28rpx;
		height: 100px;
	}
	
	.u-demo-wrap {
		border-width: 1px;
		border-color: #ddd;
		border-style: double;
		background-color: rgb(250, 250, 250);
		margin-top: 5px;
		padding: 15px 10px;
		border-radius: 10px;
	}
</style>