<template>
	<view>
		<view v-if="vif" class="u-page">
			
				<view class="wrap">
							<view class="u-demo-wrap" v-for="(item, index) in carlist" :key="index">
								{{item.supplierName+'  '+item.contacts+' 售价:'+item.phoneNumber+'万元'}}<br/>
								{{item.address}}<br/>
								
							</view>
							<u-loadmore :status="status" />
				</view>
		</view>
		<view v-else style=" position: fixed; top:100px ;left: 125px; font-size: 29px;">
			<u-icon name="info-circle" size="50" color="red"></u-icon>
			请登录
		</view>
		
	</view>
</template>

<script>
	export default {
		onLoad() {
				
		},
		onShow() {
			var userid = uni.getStorageSync('user');
			if(userid==""){
				this.vif=false;
			}else{
				this.vif=true;
			}

			this.getBrand();
		},
		data() {
			return {
				vif:false,
				brand: "品牌",
				model: 0,
				modelname: null,
				query: {
					page: 1,
					rows: 20,
					brand: null,
					codeOrName: null,
					goodsTypeId: null,
				},
				brandOptions: [{label:'所有',value:'所有'}],
				modelOptions: [{label:'所有',value:0}],
				NameOrCode:null,
				current: 0,
				status: 'loadmore',
				carlist: [],
				carlistnum: 1,
				allcarnum: null,
				page: 0
			}
		},
		
		methods: {
			getBrand(){
				uni.request({
					url:'http://192.168.212.42:8080/supplier/getComboboxList',
					method:"GET",
					success:(res)=>{
						console.log("2222222222");
						console.log(res.data);
						for(var i=0;i<res.data.length;i++){
							this.carlist.push(res.data[i]);
						}
						console.log(this.carlist);
						console.log("111111111111111111");
					}
				})
			},
			
		
		},
		}
</script>

<style lang="scss" scoped>
	.wrap {
		padding: 24rpx;
	}
	
	.item {
		padding: 24rpx 0;
		color: $u-content-color;
		font-size: 28rpx;
		height: 100px;
	}
	
	.u-demo-wrap {
		border-width: 1px;
		border-color: #ddd;
		border-style: double;
		background-color: rgb(250, 250, 250);
		margin-top: 5px;
		padding: 15px 10px;
		border-radius: 10px;
	}
</style>