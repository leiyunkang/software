<template>
	<view class="wrap">
		<u-form :model="user" ref="uForm">
			<!--小技巧 增加一个隐藏的输入框 存id-->
			<u-input v-show="false" v-model="user.id" type="text"></u-input>
			<u-form-item label-width="140" label-position="left" label="姓名" prop="trueName">
				<u-input :border="border" placeholder="请输入姓名" v-model="user.trueName" type="text"></u-input>
			</u-form-item>
			<u-form-item label-width="140" label-position="left" label="密码" prop="password">
				<u-input :password-icon="true" :border="border" type="password" v-model="user.password"
					placeholder="请输入密码"></u-input>
			</u-form-item>
			<u-form-item label-width="140" label-position="left" label="确认密码" prop="rmima">
				<u-input :password-icon="true" :border="border" type="password" v-model="user.rmima"
					placeholder="再输一次密码"></u-input>
			</u-form-item>
		</u-form>
		<u-button @click="submit" style="background-color: #1296db; color: white; left: 20%; width: 60%; margin-top: 5px;">提交</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				border: true,
				user: {}
			}
		},
		onLoad(x) {
			console.log(x),
			uni.request({
				url:`http://192.168.1.94:8080/queryInfoId?id=${x.id}`,
				success: (res) => {
					if(res.data.code*1==200){
						this.user=res.data.result;
						this.user.rmima=''
					}
				}
			})
		},
		methods: {
			submit() {
				if (this.user.password != this.user.rmima) {
					this.$u.toast("两次输入的密码不同")
					return
				}
				uni.request({
					url: "http://192.168.1.94:8080/editmyinfo",
					data: this.user,
					method: "POST",
					success: (res) => {
						if (res.data.code * 1 == 200) {
							alert("更改成功")
							uni.navigateBack();
						} else {
							this.$u.toast("失败，请更换用户名或密码尝试")
						}
					}
				})
			},
			radioChange(e) {
				//console.log(e.detail)
				this.user.leibie = e.detail.value
			}
		}
	}
</script>

<style>

</style>