<template>
	<view class="wrap">
		<u-form :model="user" ref="uForm">
			<u-form-item left-icon="account" label-width="100"  prop="name">
				<u-input placeholder="请输入姓名" v-model="user.userName" type="text"></u-input>
			</u-form-item>
			<u-form-item left-icon="lock" label-width="100"  prop="password">
				<u-input :password-icon="true" type="password" v-model="user.password" placeholder="请输入密码"></u-input>
			</u-form-item>
			<!-- 此处switch的slot为right，如果不填写slot名，也即<u-switch v-model="model.remember"></u-switch>，将会左对齐 -->
		</u-form>
		<u-button @click="submit()" style="background-color: #1296db; color: white; left: 20%; width: 60%; margin-top: 5px;">登录</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				user: {
					userName: "",
					password: ""
				},
			}
		},
		methods: {
			submit() {
				//如果成功，返回
				uni.request({
					url: 'http://192.168.212.42:8080/dologin', //仅为示例，并非真实接口地址。
					data: this.user,
					method: "POST",
					success: (res) => {
						if (res.data.code *1 == 200) {
							try {
								console.log(res.data.result)
								uni.setStorageSync('user', res.data.result);
								uni.navigateBack()
							} catch (e) {
								this.$u.toast('身份信息格式异常')
							}
						} else {
							this.$u.toast('登录失败，用户名密码错误')
						}
					}
				});
			},
		}
	}
</script>

<style>
	.u-demo-area {
		cursor: pointer;
	}
</style>