<template>
	<view>
		<view v-if="logined">
			<view>
				<div class="top_1" style="width: 400px; height: 200px;">
					<view class="u-flex" id="bust">
						<view class="u-m-r-10">
							<u-avatar src="../../static/images/special.webp" size="140"></u-avatar>
						</view>
						<view class="u-flex-1" id="name">
							<view class="u-font-18 u-p-b-20">{{user.trueName}}</view>
							<view class="u-font-14 u-tips-color">职位：{{user.remarks}}</view>
						</view>
					</view>
				</div>
			</view>
			<view class="u-m-t-20">
				<u-cell-group>
					
					<u-cell-item icon="search" title="查询订单" @click="queryOrders(user.userId)"></u-cell-item>
					<u-cell-item icon="account" title="查询客户信息" @click="queryCustomer(user.userId)"></u-cell-item>
					<u-cell-item icon="integral" title="个人业绩" @click="queryPerformance(user.userId)"></u-cell-item>
				</u-cell-group>
			</view>
			<view class="u-m-t-20">
				<u-cell-group>
					<u-cell-item id="wuhsi" icon="edit-pen-fill" title="更改个人信息"
						@click="goupdate(user.userId)"></u-cell-item>
					<u-cell-item icon="man-delete" title="退出" @click="quit()"></u-cell-item>
				</u-cell-group>
			</view>
		</view>
		<view v-else>
			<u-navbar :is-back="false" title="　" :border-bottom="false">
				<view class="u-flex u-row-right" style="width: 100%;">
					<view class="camera u-flex u-row-center">
						<u-icon name="camera-fill" color="#000000" size="48"></u-icon>
					</view>
				</view>
			</u-navbar>
			<view class="u-flex user-box u-p-l-30 u-p-r-20 u-p-b-30">
				<view class="u-m-r-10">
					<u-avatar src="../../static/images/personal.png" size="140"></u-avatar>
				</view>
				<view class="u-flex-1">
					<view class="u-font-18 u-p-b-20">匿名用户</view>
					<view class="u-font-14 u-tips-color">请登录</view>
				</view>

			</view>

			<view class="u-m-t-20">
				<u-cell-group>
					<u-cell-item icon="man-add" title="登录" @click="geLogin()" ></u-cell-item>
				</u-cell-group>
			</view>
		</view>
		<u-tabbar v-model="current" :list="list" :mid-button="true"></u-tabbar>
	</view>
</template>

<script>
	import queryCustomerVue from '../wz/queryCustomer.vue'
	export default {
		data() {
			return {
				list: [{
						iconPath: "/static/images/goods.png",
						selectedIconPath: "/static/images/goods1.png",
						text: '首页',
						count: 0,
						isDot: false,
						customIcon: false,
						pagePath: "/pages/index/index"
					},
					{
						iconPath: "/static/images/goods.png",
						selectedIconPath: "/static/images/goods1.png",
						text: '库存',
						count: 0,
						isDot: false,
						customIcon: false,
						pagePath: "/pages/index/index"
					},
					{
						iconPath: "/static/images/sale.png",
						selectedIconPath: "/static/images/sale1.png",
						text: '销售',
						isDot: false,
						midButton: true,
						customIcon: false,
						pagePath: "/pages/dxy/sale"
					},
					{
							iconPath: "/static/images/goods.png",
							selectedIconPath: "/static/images/goods1.png",
							text: '进货',
							count: 0,
							isDot: false,
							customIcon: false,
							pagePath: "/pages/index/index"
						},
						{
							iconPath: "/static/images/sale.png",
							selectedIconPath: "/static/images/sale1.png",
							text: '退换',
							isDot: false,
							midButton: true,
							customIcon: false,
							pagePath: "/pages/dxy/sale"
						},
						{
							iconPath: "/static/images/my.png",
							selectedIconPath: "/static/images/my1.png",
							text: '管理',
							count: 0,
							isDot: false,
							customIcon: false,
							pagePath: "/pages/dxy/myself"
						},
						{
							iconPath: "/static/images/my.png",
							selectedIconPath: "/static/images/my1.png",
							text: '我的',
							count: 0,
							isDot: false,
							customIcon: false,
							pagePath: "/pages/dxy/myself"
						},
				],
				current: 0,

				logined: false,
				user: {
					userName: "管理员",
					remarks: "root",
					userId: "0"
				} //初始

			}

		},
		onShow() {
			try {
				const value = uni.getStorageSync('user')
				if (value) {
					if (value) {
						if (!this.logined) {
							this.user = value
						}
						this.logined = true
					}
				} else {
					this.logined = false
				}
			} catch (e) {
				// error
			}
		},
		onPullDownRefresh() {
			console.log(this.user.userId)
			uni.request({
				url: `http://192.168.212.42:8080/queryInfoId?id=${this.user.userId}`,
				success: (res) => {
					if (res.data.code * 1 == 200) {
						this.user = res.data.result;
					}
					setTimeout(function() {
						uni.stopPullDownRefresh();
					}, 500);
				}
			})
		},
		methods: {
			geLogin() {
				uni.navigateTo({
					url: '/pages/wz/login'
				})
			},
			quit() {
				uni.setStorageSync("user", "");
				this.logined = false
			},
			goupdate(x) {

				uni.navigateTo({
					url: `/pages/wz/editmyinfo?id=${x}`
				})
			},
			queryOrders(x) {
				uni.navigateTo({
					url: `/pages/wz/queryOrders?id=${x}`
				});
			},
			queryCustomer(x) {
				uni.navigateTo({
					url: `/pages/wz/queryCustomer?id=${x}`
				});
			},
			queryPerformance(x) {
				uni.navigateTo({
					url: `/pages/wz/performance?id=${x}`
				});
			}
		}
	}
</script>
<style>
	#bust{
		padding-top: 120px;
		padding-left: 10px;
	}
	#name{
		color: #ffffff;
		font-family: "微软雅黑";
	}
	.top_1 {
		background-image: url(../../static/images/zhuanYe.png);
	}
	#cell_1{
		height: 10%;
	}
</style>