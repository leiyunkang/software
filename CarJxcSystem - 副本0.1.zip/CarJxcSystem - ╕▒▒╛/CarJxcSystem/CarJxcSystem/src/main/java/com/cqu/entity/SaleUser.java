package com.cqu.entity;

import lombok.Data;

@Data
public class SaleUser {

    private String date;
    private double saleTotal;

}
