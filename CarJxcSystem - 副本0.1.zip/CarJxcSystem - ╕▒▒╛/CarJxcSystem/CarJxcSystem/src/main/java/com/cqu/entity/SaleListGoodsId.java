package com.cqu.entity;

import lombok.Data;

import java.util.List;

@Data
public class SaleListGoodsId {
    private List<SaleListGoods> listSaleListGooods;
    private Integer listId;
}

