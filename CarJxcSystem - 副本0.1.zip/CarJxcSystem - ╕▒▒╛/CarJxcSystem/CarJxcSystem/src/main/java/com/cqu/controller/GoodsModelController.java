package com.cqu.controller;


import com.cqu.dao.GoodsDao;
import com.cqu.entity.CarsType;
import com.cqu.entity.Goods;
import com.cqu.entity.QueryCarInvent;
import com.cqu.entity.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
public class GoodsModelController {

    @Autowired
    private JdbcTemplate jdbc;

    @Autowired
    private GoodsDao goodsDao;

    @GetMapping("/loadCarsType")
    public Result getCarsType(){
        Result res = new Result();
        try{
            List<CarsType> ct = null;
            ct = jdbc.query("SELECT goods_type_name, goods_type_id FROM t_goods_type WHERE p_id=8",new BeanPropertyRowMapper<>(CarsType.class));
            res.setCode(200);
            res.setResult(ct);
        }catch (DataAccessException e){
            res.setResult("error:"+e.getMessage());
            res.setCode(201);
        }
        return res;
    }

    @PostMapping("/getCarsInventoryNum")
    public Result getCarsInVentoryNum(@RequestBody QueryCarInvent querycar){
        Result res = new Result();
        try{
            Integer cnt = goodsDao.getCarsInventoryCount(querycar.getCodeOrName(),querycar.getGoodsTypeId(),querycar.getBrand());
            res.setCode(200);
            res.setResult(cnt);
        }catch (DataAccessException e){
            res.setResult("error:"+e.getMessage());
            res.setCode(201);
        }
        return res;
    }

    @PostMapping("/getCarsInventory")
    public Result getCarsInventory(@RequestBody QueryCarInvent querycar){
        Result res = new Result();
        try {
            Integer page = querycar.getPage();
            Integer rows = querycar.getRows();
            Integer offset = (page - 1) * rows;
            List<Goods> ct = null;
            ct = goodsDao.getCarsInventoryList(offset,rows,querycar.getCodeOrName(),querycar.getGoodsTypeId(),querycar.getBrand());
            res.setCode(200);
            res.setResult(ct);
        }catch (DataAccessException e){
            res.setCode(201);
            res.setResult("error:"+e.getMessage());
        }
        return res;
    }

}

