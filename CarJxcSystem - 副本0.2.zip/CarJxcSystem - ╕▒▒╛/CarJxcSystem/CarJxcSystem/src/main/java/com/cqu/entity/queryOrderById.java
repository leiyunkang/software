package com.cqu.entity;

import lombok.Data;

@Data
public class queryOrderById {
    private Integer saleListId;
    private String saleNumber;
    private double amountPaid;
    private double amountPayable;
    private String saleDate;
    private String customerName;
    private Integer userId;
    private Integer customerId;
    private boolean open=false;
    private boolean disabled=false;
}
