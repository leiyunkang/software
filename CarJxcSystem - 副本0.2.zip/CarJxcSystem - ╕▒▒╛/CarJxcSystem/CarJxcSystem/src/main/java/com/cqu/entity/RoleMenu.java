package com.cqu.entity;

import lombok.Data;

@Data
public class RoleMenu {

  private Integer roleMenuId;
  private Integer menuId;
  private Integer roleId;

}
