package com.cqu.entity;

import lombok.Data;

@Data
public class SaleDataSupplier {

    private String supplier;
    private int date;
    private double saleTotal;
    private double purchasingTotal;

}
