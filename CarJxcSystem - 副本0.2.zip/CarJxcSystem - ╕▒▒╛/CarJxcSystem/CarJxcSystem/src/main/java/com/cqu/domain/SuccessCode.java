package com.cqu.domain;

/**
 * @description 成功码
 */
public interface SuccessCode {

    int SUCCESS_CODE = 100;
    String SUCCESS_MESS = "请求成功";

}
