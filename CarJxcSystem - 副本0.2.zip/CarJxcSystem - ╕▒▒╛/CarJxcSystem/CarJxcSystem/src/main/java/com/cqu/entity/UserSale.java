package com.cqu.entity;

import lombok.Data;

@Data
public class UserSale {
    private Integer userdeid;

}
