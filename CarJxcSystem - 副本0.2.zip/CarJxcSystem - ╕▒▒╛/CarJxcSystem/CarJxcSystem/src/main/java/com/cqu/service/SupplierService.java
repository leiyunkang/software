package com.cqu.service;

import com.cqu.domain.ServiceVO;
import com.cqu.entity.Supplier;

import java.util.List;
import java.util.Map;


public interface SupplierService {

    List<Supplier> getComboboxList(String q);

    Map<String,Object> list(Integer page, Integer rows, String supplierName);

    ServiceVO save(Supplier supplier);

    ServiceVO delete(String ids);
}
