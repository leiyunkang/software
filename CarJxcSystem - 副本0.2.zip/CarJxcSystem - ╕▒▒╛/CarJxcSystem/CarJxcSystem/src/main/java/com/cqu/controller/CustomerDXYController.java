package com.cqu.controller;

import com.cqu.dao.CustomerDao;
import com.cqu.dao.GoodsDao;
import com.cqu.dao.SaleListGoodsDao;
import com.cqu.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
public class CustomerDXYController {

    @Autowired
    private JdbcTemplate jdbc;

    @Autowired
    private CustomerDao customerDao;

    @Autowired
    private SaleListGoodsDao saleListGoodsDao;
    @Autowired
    private GoodsDao goodsDao;

    @PostMapping("/getcustomerlist")
    public Result getCustomersList(@RequestBody QueryCutom queryCutom){
        Result res = new Result();
        try{
            List<Customer> ct = null;
            ct = customerDao.getCustomerListByNameLike(queryCutom.getNamelike());
            res.setCode(200);
            res.setResult(ct);
        }catch (DataAccessException e){
            res.setCode(201);
            res.setResult("error:"+e.getMessage());
        }
        return res;
    }

    @PostMapping("/savesalelist")
    public Result saveSaleList(@RequestBody SaleList saleList){
        Result res = new Result();
        try{
            Integer id;
            saleListGoodsDao.saveSaleList(saleList);
            id=saleList.getSaleListId();
            res.setCode(200);
            res.setResult(id);
        }catch (DataAccessException e){
            res.setCode(201);
            res.setResult("error:"+e.getMessage());
        }
        return res;
    }

    @PostMapping("/savesalelistgoods")
    public Result savesalelistgoods(@RequestBody SaleListGoodsId query){
        Result res =new Result();
        try{
            Integer id=query.getListId();
            for(SaleListGoods saleListGoods : query.getListSaleListGooods() ){
                saleListGoods.setSaleListId(id);
                saleListGoodsDao.saveSaleListGoods(saleListGoods);

                Goods goods = goodsDao.findByGoodsId(saleListGoods.getGoodsId());
                goods.setInventoryQuantity(goods.getInventoryQuantity()-saleListGoods.getGoodsNum());
                goods.setState(2);
                goodsDao.updateGoods(goods);
                res.setCode(200);
                res.setResult("save successfully!");
            }
        }catch (DataAccessException e){
            res.setCode(201);
            res.setResult("error:"+e.getMessage());
        }
        return res;
    }
}

