package com.cqu.entity;

import lombok.Data;

@Data
public class PerformanceMonth {
    private String saleDate;
    private Integer totalSales;
    public void setSaleDate(String saleDate_1) {
        this.saleDate = saleDate_1;
    }
    public void setTotalSales(Integer totalSales) {
        this.totalSales = totalSales;
    }
}
