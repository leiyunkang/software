package com.cqu.entity;

import lombok.Data;

@Data
public class CarsType {
    private Integer goods_type_id;
    private String goods_type_name;
}
